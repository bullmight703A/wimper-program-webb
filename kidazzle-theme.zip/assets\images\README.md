# Logo Files

Place the Kidazzle logo files here:

- `Kidazzle-logo.png` or `Kidazzle-logo.svg` - Standard logo for web use
- `Kidazzle-logo-highres.png` - High resolution logo for retina displays

The logo should be the colorful hexagon/icosahedron shape with "Kidazzle" text.
